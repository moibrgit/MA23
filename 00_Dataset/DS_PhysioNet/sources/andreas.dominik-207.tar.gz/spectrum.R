#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# spectrum.R
# comprises functions create and work with stft frequency spetra of PCGs
#


require(seewave)



# Generates a time series and returns the 
# frequency spectrum as list of class PCGSpectrum with
# elements: ampl [freqs,bins]   amplitude spectrum from stft
#           pow [freqs,bins]    power spectrum
#           time [bins]         time steps (center of bins)
#           freq [freqs]        frequencies in Hz
#           bin                 length of bins in ms
#
# pcg                object of class "PCG"
#
pcg.create.spectrum <- function(wav){
  
  # TODO: spectrum könnte verschoben sein!
  
  f <- wav@samp.rate
  
  spectrum <- spectro(wav, fftw=T, plot=F, wl=256, wn="hanning", zp=1, ovlp=90, db="max0", norm=T)
  spectrum$freq <- spectrum$freq * 1000   # from kHz to Hz
  # spectrum$time <- spectrum$time * 1000   # from sec to millisec
  spectrum$freq[is.na(spectrum$freq)] <- 0
  spectrum$amp[is.na(spectrum$amp)] <- 0
  
  spectrum$pow <- spectrum$amp * spectrum$amp
  
  spectrum$amp <- spectrum$amp + 30         # shift to positive values
  amplify <- 15                             # amplify small values
  spectrum$amp <- spectrum$amp + amplify          
  spectrum$amp[spectrum$amp < 0] <- 0       # set 0-line

  return(spectrum)
}

# Generates bands from a
# frequency spectrum and returns a data.frame with
# elements: 
#   index      index of bins
#   time       time of bins (center of bin)
#   low        numeric vector with band average values
#   beats      ...
#   hi1        ...
#   ...
#
# spectrum           list of class "spectrum"
# bin                length of bin sin ms
# bands=CONFIG$bands frequency bands to be returned
#
# value:
# Lict of class "PCGSpectrum" with added elements:
#   spectrum   raw spectrum (list from seewave::spectro)

pcg.create.bands <- function(spectrum, bin=0.010, band.defs=CONFIG$bands){
  
  # TODO: spectrum könnte verschoben sein!
  
  # define mid-points of bins in millisec:
  sec.total <- tail( spectrum$time, n=1)
  step <- bin   # in sec
  
  bins <- seq(from=step/2, by=step, to=sec.total)
  time <- bins
  index <- seq_along(bins)
  bands <- data.frame(index=index, time=time)

  # sum-up to bands:
  for (n in names(band.defs)) {
    
    band.name <- n
    band.from <- band.defs[[n]][1]
    band.to <- band.defs[[n]][2]
    
    band.freqs <- seq_along(spectrum$freq)[(spectrum$freq >= band.from) & (spectrum$freq < band.to)]
    band.rows <- spectrum$amp[band.freqs, ]
    band <- colMeans(band.rows)
    #band <- colSums(band.rows)
    
    band.resampled <- approx(x=spectrum$time, y=band, xout=bins)
    
    bands[[n]] <- band.resampled$y
  }
  
  # normalise bands "beat" and "low":
  if ("beat" %in% names(bands))
    bands$beat.zero <- spline.zero(time, bands$beat, all.knots=TRUE, spar=0.65, smooth=FALSE)
  if ("low" %in% names(bands))
    bands$low.zero <- spline.zero(time, bands$low, all.knots=TRUE, spar=0.65, smooth=FALSE)
  
  # generates an artefact frame
  bands$artefact <- rep(0,length(bands$index))
  
  
  return(bands)
}


