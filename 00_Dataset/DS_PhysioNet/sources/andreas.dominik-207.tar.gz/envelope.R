#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# envelope.R
# Returns the Hilbert envelope of the recording

# Returns the hull of a recording in the 
# dataset wav, from Hilbert transformation.
# list has elements $ms (millisec) and $hilbert (hull), wav and smooth (= a
# very strongly smoothed hull for peak detection)
# returned object is a list of class type Envelope
#
# wav : data as class Wave [package "tuneR"] 
# plot : plot window with Hilbert curve (default = F)
#
pcg.get.envelope <- function( wav, plot=FALSE) {
  
  # calc. Hilbert transform and normalise by 99.9% percentile:
  # smooth hull with window +- smooth.win
  smooth.win <- 75 # [samples]
  
  hull <- env(wav,  envt="hil", plot=plot, fftw=TRUE, ksmooth=kernel("dirichlet", smooth.win, 2))[,1]  # smoothed
  
  # add clipped begin/end:
  hull <- c(rep(hull[1], smooth.win), hull, rep(tail(hull,1), smooth.win))
  
  hull.max <- quantile(hull, probs=0.98, na.rm=TRUE, names=FALSE)
  hull <- hull/hull.max
  
  # make data.frame:
  freq = wav@samp.rate
  sec <- (seq_along(hull)-1) / freq  # calc ms from index
  
  hull <- data.frame(time = sec, 
                     hilbert = hull) 
  
  return(hull)
}
