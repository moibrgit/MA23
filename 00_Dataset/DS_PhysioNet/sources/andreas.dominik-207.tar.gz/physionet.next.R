#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#
# next function for Physionet Challenge
#
#
library(seewave)
library(tuneR)
library(fftw)
library(methods)

source("config.R")
source("interface.R")
source("spectrum.R")
source("pcg.R")
source("io.R")
source("beats.R")
source("envelope.R")
source("simon.R")
source("util.R")
source("cinc.R")
source("classi.R")


# test if there is one argument: if not, return an error
#
args <- commandArgs(trailingOnly=TRUE)

CONFIG$sample.dir <- "./"

if (length(args) < 1) {
  stop("Name of sample must be supplied!")
  
} else if (length(args) > 1) {
  stop("Only name of sample must be supplied!")

} else {
  
  name <- args[1]
}

print(paste("Working on sample", name))
cinc.next(name)
  