#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#


# return the PCG with added beats 
#   as dataframe with elements
# $index 
# $s1     in sec
# $s2     in sec
#
# and with s1.s1 and s1.s2
#
# 1st attempt is to extract beats from "beat" band. 
# if <3 beats found, "low" band is used.
# if still <2 beats, the limits are reduced
#
# pcg   : audio data recording with computet spectrum; calls "PCG"
#
pcg.add.beats <- function(pcg, plot=FALSE){
  
  num.whish <- ceiling(pcg@duration * CONFIG$whish.rate)  # number of beats wanted
  #num.min   <- CONFIG$min.beats             # minimum beats necessary
  
  beats <- list()
  s1.s1 <- 0.0
  s1.s2 <- 0.0
  
  # try band "beat" firs, then band "low"
  # and reduce limits in 5% steps, until beats found or lower limit reached:
  #
  sensitivity <- 1.0
  min.sensitivity <- 0.6
  try.bands <- c("beat.zero", "low.zero")
  #try.bands <- c("low.zero", "beat.zero")
  try.now <- 1
  enough.beats <- FALSE
  while (!( enough.beats || (sensitivity < min.sensitivity) )) {
    
    ans <- extract.beats.from.band(band=try.bands[try.now], pcg,
                                   left=50, right=25, sensitivity=sensitivity,
                                   plot=plot)
    pcg <- ans$pcg
    beats[[length(beats)+1]] <- ans$beats
      
      
    num.beats <- length(beats[[length(beats)]]$s1.sec)
    
    
    if (num.beats >= num.whish) {
      enough.beats <- TRUE
      break
    }
    
    
    try.now <- try.now + 1
    if (try.now > length(try.bands)) try.now <- 1
    sensitivity <- sensitivity * 0.95
    
  }
  
  # beat finding was successful:
  if (enough.beats && beats[[length(beats)]]$s1.s1>0 && beats[[length(beats)]]$s1.s2>0 ){
    
    # delete s1 <= s2 
    #s1.s2.equal <- c(0,beats[[length(beats)]]$s2.sec)>=c(beats[[length(beats)]]$s1.sec,0)
    
    
    s2.i <- t2i( beats[[length(beats)]]$s2.sec,pcg@bands$time)
    s1.i <- t2i( beats[[length(beats)]]$s1.sec,pcg@bands$time)
    s2.amp <- pcg@bands$beat[s2.i]
    s1.amp <- pcg@bands$beat[s1.i]
    
    s1.s2.equal <- rep(FALSE,length(s1.i))
    
    for(j in seq(length(s1.i)-1) ) {
      if(s2.i[j]>=s1.i[j+1]){
        if(s1.amp[j]>s1.amp[j+1]){
          s1.s2.equal[j+1] <- TRUE
        }else{
          s1.s2.equal[j] <- TRUE
        }
      }
    }
    
    beats[[length(beats)]]$s1.sec<-beats[[length(beats)]]$s1.sec[!s1.s2.equal]
    beats[[length(beats)]]$s2.sec<-beats[[length(beats)]]$s2.sec[!s1.s2.equal]
    
    # remove NA
    #beats[[length(beats)]]$s1.sec<-beats[[length(beats)]]$s1.sec[!beats[[length(beats)]]$s1.sec %in% NA]
    #beats[[length(beats)]]$s2.sec<-beats[[length(beats)]]$s2.sec[!beats[[length(beats)]]$s2.sec %in% NA]
    
    
    final.beats <- data.frame( s1 = beats[[length(beats)]]$s1.sec,
                               s2 = beats[[length(beats)]]$s2.sec)
    
    s1.s1 <- beats[[length(beats)]]$s1.s1
    s1.s2 <- beats[[length(beats)]]$s1.s2
    raw.beats <- beats[[length(beats)]]$raw
    
    # beat finding was NOT succesful => use raw only:
  } else {   

    final.beats <- data.frame( s1 = numeric(0), s2 = numeric(0))
    s1.s1 <- 0.0
    s1.s2 <- 0.0
    
    enough.raw <- FALSE
    i = 1
    while (!( enough.raw || (i > length(beats))) ) {
      
      raw.beats <- beats[[i]]$raw
      if (length(raw.beats) >= num.whish) {
        
        enough.raw <-TRUE
      }
      i <- i+1
    }
    if (! enough.raw) {
      raw.beats <- beats[[1]]$raw
    }
  }
  
  pcg@beats <- final.beats
  pcg@raw.beats <- raw.beats
  pcg@s1.s1 <- s1.s1
  pcg@s1.s2 <- s1.s2
  return(pcg)
}

# return list of beats as dataframe with elements
# $index and $ms (millisec and index of beat)
# Algorithm:
#   * prepare beats band adhere to zero by spline-substraction
#     and smoothing (spline)
#   * search for peaks in band curve
#     Peaks must be > 0.25 and maximum in window of interest (eg. +-50ms)
#   * extract S1-S2-distance for S1-detection
#     from peak-list, calc diffs (list has: S1-S1 (rr), S1-S2, S2-S2, S2-S1)
#     get maximum in histogram of list (breaks=???)
#      if (maximum between 200 - 390) -> define S1-S2 as max
#      else search max between 200 - 390
#        if (max has freq >= 5) use as S1-S2
#        else use abs. max
#   * filter beat list: Only beat[i], if [i+1] is S1-S2 +- 50
#      one of the peaks must be > 0.5
#
# band.name  : name of band, used for peak detection
# beat.bin   : length of bins in band in millisec
# left       : region of interest left of maximum in ms
# right      : roi right of beat in ms 
# sensitivity: s. of beat detection; 1.0 == 0.25 in normalised amplitude. 
#              Smaller value => higher sensitivity. 0.9 => 0.9 * 0.25
# plot       : if TRUE, intermediate plots are created (with "wait until keypressed")
#
extract.beats.from.band <- function( band.name, pcg, left=50, right=50, sensitivity=1.0,
                                     plot=FALSE) {
  
  band <- pcg@bands[[band.name]]
  t <- pcg@bands$time
  bin <- t[2] - t[1]
  band.ori <- band
  s1.s1 <- 0.0
  s1.s2 <- 0.0
  
  if (plot) {
    plot(t, band.ori, type="l", ylim=c(0,30), main=paste("Band:", band.name))
    
    wait.until.enter()
  }
  
  # normalise:
  band.max <- quantile(band, probs=0.95, na.rm=TRUE, names=FALSE)
  band <- band/band.max
  #smooth.model <- smooth.spline(t, band, all.knots=TRUE, spar=0.65)
  smooth.model <- smooth.spline(t, band, all.knots=TRUE, spar=0.70)

  band.smoothed <- predict(smooth.model, t)$y
  
  if (plot) {
    plot(t, band, type="l", main=paste("Smoothed:", band.name))
    lines(t, band.smoothed,col="red")
    abline(h=0.25)
    
    wait.until.enter()
  }
  
  # detect peaks
  # and transpose from ms to index
  delta.ms <- bin * 1000
  
  left <-  round(left / delta.ms)
  right <- round(right  / delta.ms)
  
  width <- left + 1 + right
  total <- length(band) 
  
  # moving window:
  from <- 1                # start at beginning
  to <- from + width - 1
  
  # init result list
  beats.raw <- data.frame(index=numeric(0), sec=numeric(0), amp=numeric(0))
  beats.raw.artefact <- data.frame(index=numeric(0), sec=numeric(0), amp=numeric(0))
  
  # move window until end of record
  while (to <= total) {
    
    win <- band.smoothed[seq(from=from, to=to)]
    beat.index <- which.max(win) + from -1
    
    if (is.beat(beat.index, band.smoothed, left, right, limit.detect=0.25 * sensitivity)) {
      
      # test if maximum is noise 
      temp1 <- pcg.is.noise(pcg, t[beat.index])
      pcg <- temp1$pcg
      flag.noise <- temp1$flag.noise
      
      # test if maximum is artefact 
      temp2 <- pcg.is.artefact(pcg, t[beat.index])
      pcg <- temp2$pcg
      flag.artefact <- temp2$flag.artefact
      
      if(!flag.artefact && !flag.noise){
        
        beats.raw[nrow(beats.raw)+1,] <- c(beat.index, t[beat.index], band.smoothed[beat.index])
        from <- beat.index +right   # +1 better, but +right faster!
        
      } else {
        
        from <- to + 1
       #cat(t[beat.index]," perc=",temp2$perc,"\n") #DEBUG
      
      }
      
      if(flag.artefact){
        beats.raw.artefact[nrow(beats.raw.artefact)+1,] <- c(beat.index, t[beat.index], band.smoothed[beat.index])
      }
      
    } else {
      from <- to + 1 # no beat, artefact or noise
    }
    to <- from + width - 1
  }
  
  if (plot) {
    plot(t, band, type="l")
    lines(t, band.smoothed,col="red")
    points(beats.raw$sec, beats.raw$amp, pch=19)
    
    wait.until.enter()
  }
  
  # Proof if artefacts diffs are normal distributed
  # if TRUE merge artefacts with raw beats
  
  if(length(beats.raw.artefact$sec) >= 6){
    diffs <- c(diff(beats.raw.artefact$sec))
    swt<-shapiro.test(diffs)
    artefact.alpha <- 0.001
    
    if(swt$p.value<= artefact.alpha){
      # TODO: merge only if artefact is in norm
      beats.raw <- merge(as.data.frame(beats.raw),as.data.frame(beats.raw.artefact),all.x = TRUE,all.y = TRUE)
      pcg@bands$artefact <- rep(0,length(pcg@bands$index)) # reset artefacts
    }
  }

  
  
  # make and analyse histogram (only if at least 4 points)
  # otherwise just return raw values:
  #
  beats <- list(s1.sec=numeric(0), 
                s2.sec=numeric(0),
                raw=beats.raw$sec,
                s1.s1 = 0,
                s1.s2 = 0)
  
  if (nrow(beats.raw) < 4) {
    
    return(list(pcg=pcg, beats=beats))
  }
  
  beats.raw$amp.low <- pcg@bands$low.zero[beats.raw$index] # prepare for extract.s1.s2
  
  beats.i <- extract.s1.s2(beats.raw, sensitivity=sensitivity, plot)
    
  beats.i <- filter.by.s1.s1(beats.raw, beats.i, sensitivity=sensitivity, plot)
        
  if (length(beats.i$s2.i) == 0) {
    
    return(list(pcg=pcg, beats=beats))
  }
  
  s1.i <- beats.i$s1.i   # indices of s1 in beats.raw
  s2.i <- beats.i$s2.i   # indices of s2 in beats.raw
  s1.s2 <- beats.i$s1.s2
  s1.s1 <- beats.i$s1.s1
  
  beats$s1.sec <- beats.raw$sec[s1.i]
  beats$s2.sec <- beats.raw$sec[s2.i]
  beats$raw <- beats.raw$sec
  beats$s1.s1 <- s1.s1
  beats$s1.s2 <- s1.s2
  
  if (plot) {
    plot(t, band, type="l", main="Beats (red=S1, blue=S2, black=raw)")
    points(beats$s1.sec, rep(1.0, length(beats$s1.sec)), pch=19, col="red")
    points(beats$s2.sec, rep(0.95, length(beats$s2.sec)), pch=19, col="blue")
    points(beats$raw, rep(0.85, length(beats$raw)), pch=19, col="black")
    
    wait.until.enter()
  }
  return(list(pcg=pcg, beats=beats))
}

# test if the value at index index is a beat according
# to the criteria:
# * maximum in range (index-left ... index+right)
# * total val > 0.5 (limit.detect)
#
# i : beat index
# b : complete row of values
# left : region of interest to the left in index
# right : region of interest to the right in index
#
is.beat <- function( i, band, left, right, limit.detect) {
  
  is.max <- TRUE
  
  if (band[i] < limit.detect) { is.max <- FALSE }  # minimum power
  
  if ( i-left < 1) { is.max <- FALSE }             # beginning of recording
  
  if ( i+right > length(band)) { is.max <- FALSE } # end of recording
  
  if (is.max == TRUE)
    if (band[i] < max(band[seq(i-left, i+right)])) { is.max <- FALSE } # not max in window (centered to i) 
  
  return( is.max)
}


# Returns the index (index in vector of beats) of 
# the most prominent beat, if a beat is in the range of time;
# else 0.
#
# beats      : data.frame with $index and $sec of beats
# from       : start of window in sec
# to         : end of window in sec
#
is.beat.in.range <- function(beats, from, to) {
  
  # create vector of s2-candidates in range:
  beats.i <- numeric(0)
  for (i in seq_along(beats$index)) {
    
    if ((beats$sec[i] >= from) && ( beats$sec[i] <= to))
      beats.i <- c(beats.i, i) 
  }
  
  if (length(beats.i) > 0) {
    
    # get maximum peak of candidates:
    beats.amp <- beats$amp[beats.i]
    max.i <- which.max(beats.amp)
    
    best.match <- beats.i[max.i]
    
  }else{
    
    best.match <- 0
  }
  
  return( best.match)
}


# make s1 and s2 list form raw beats
# and returns list(s1, s2)
#
# beats.raw  list of beats
#           data.frame(index=numeric(0), sec=numeric(0), amp=numeric(0))
#
extract.s1.s2 <- function(beats.raw, sensitivity = 1.0, plot=FALSE){
  
  # empty data.frame to be returned, if no s1.s2-distance found:
  beats.i <- list(s1.i = numeric(0),
                  s2.i = numeric(0),
                  s1.s2 = 0.0,
                  s1.s1 = 0.0)
  
  # make and analyse histogram (only if at least 4 points)
  # otherwise just return raw values:
  #
  if (nrow(beats.raw) < 4){
    return( beats.i)
  }
    
  diffs <- c(diff(beats.raw$sec))
  d <- density(diffs, bw="SJ", n=1024)
  diffs<-c(diffs,0)
  beats.raw$diffs <-diffs
  
  if (plot) {
    plot(d, main= "Density of diffs between raw beats")
    wait.until.enter()
  }
  
  #   *  from peak-list, calc diffs (list has: S1-S1 (rr), S1-S2, S2-S2, S2-S1)
  #   *  get maximum in density of list in range 175-395ms
  #   *  check if max is > 2 times mean in window
  #      if not: set to 300 ; i.e. no rescaling done
  #   *  filter beat list: Only beat[i], if in S1-S2 +- range is another peak
  #      one of the peaks must be > 0.5
  
  maxi <- find.maxima(d$x, d$y, from=0.180, to=0.400, win=0.050, overlap=0.5)
  maxi.l <- find.maxima(d$x, d$y, from=0.055, to=0.180, win=0.050, overlap=0.5)
  
  # remove all maxima, that are not higher as 1.2 * mean(d)
  maxi <- maxi[maxi$y / mean(d$y[(d$x>=0.055) & (d$x<=0.400)]) >= 1.2,]
  maxi.l <- maxi.l[maxi.l$y / mean(d$y[(d$x>=0.055) & (d$x<=0.400)]) >= 1.2,]
  
  # return only raw beats, if no maxima in range:
  if (nrow(maxi) == 0) {
    beats.i$s1.i <- 0
    return(beats.i)
  }
  
  # smallest max.t in window right:
  maxi.r <- maxi[which.min(maxi$t),]
  
  # max$amp in window left:
  maxi.l <- maxi.l[which.max(maxi.l$y),]
    
  # max value in d, between in window of S1-S2-values
  max.d <- maxi.r$y
  max.t <- maxi.r$t
  s1.s2 <- max.t
  
  # range from half of max.t peak
  max.h <- max.d/2
  limit <- CONFIG$s2.tolerance / sensitivity
  peak.d.x<-d$x[(d$y>=max.h) & (d$x>=(max.t-limit)) &  (d$x<=(max.t+limit))]
  delta.s1.s2 <- tail(peak.d.x,n=1)-peak.d.x[1]
  
  # Correct S1.s2 max in denisty if SeS exist (maxi.l exist too)
  ses <- FALSE
  
  if( !(length(maxi.l$t)==0 || length(maxi.l$y)==0)){
    
    b.1 <- numeric()
    b.2 <- numeric()
    b.3 <- numeric()
    b.1.2.3 <- c(0,0,0)
   
    
    for(i in (1:(length(diffs)-1))){
      b.1.2.short <- (diffs[i] <= maxi.l$t+limit) && (diffs[i] >= maxi.l$t-limit)
      b.2.3.long <- (diffs[i+1] <= maxi.r$t+limit) && (diffs[i+1] >= maxi.r$t-limit)
      
      b.1.2.long <- (diffs[i] <= maxi.r$t+limit) && (diffs[i] >= maxi.r$t-limit)
      b.2.3.short <- (diffs[i+1] <= maxi.l$t+limit) && (diffs[i+1] >= maxi.l$t-limit)
      
      if((b.1.2.short && b.2.3.long)||(b.1.2.long && b.2.3.short)){
        b.1 <- beats.raw$amp.low[i] 
        b.2 <- beats.raw$amp.low[i+1]
        b.3 <- beats.raw$amp.low[i+2]
        inc <- which.min(c(b.1,b.2,b.3))
        b.1.2.3[inc]<-b.1.2.3[inc]+1
      }
    }
    
    if(sum(b.1.2.3)>0){
      b.1.2.3 <- b.1.2.3 / sum(b.1.2.3)
      ses <- which.max(b.1.2.3)==2
    }

    # b.1.2.3: [0 1 0] = Ses / [1 0 0] = DeS / [0 0 1] = DeS
    if(ses){
      # max value in d, between in window of S1-S2-values
      max.d <- maxi.r$y + maxi.l$y
      max.t <- maxi.r$t + maxi.l$t
      s1.s2 <- max.t
      delta.s1.s2 <- limit
    }
    
  }
  
  # filter only S1 and S2 sounds (S2 must follow in s1.s2 +- delta.s1.s2, other beats may be between s1 and s2):
  # delta.s1.s2 <- CONFIG$s2.tolerance / sensitivity # sec
  
  s1.i <- numeric()
  s2.i <- numeric()
  
  for (i in seq_along(beats.raw$index)){
    
    s2.one <- is.beat.in.range(beats.raw,
                               from= beats.raw$sec[i] + s1.s2 - delta.s1.s2/2, 
                               to= beats.raw$sec[i] + s1.s2 + delta.s1.s2/2)
    
    if (s2.one > 0) {
      s1.i <- c(s1.i, i)
      s2.i <- c(s2.i, s2.one)
    }
  }
  
  # filter only > 0.5 (one of both)
  s1.filter <- beats.raw$amp[s1.i] > 0.5 * sensitivity
  s2.filter <- beats.raw$amp[s2.i] > 0.5 * sensitivity
  s1.s2.filter <- s1.filter | s2.filter
  
  beats.i$s1.i <- s1.i[s1.s2.filter]
  beats.i$s2.i <-s2.i[s1.s2.filter]
  beats.i$s1.s2 <- s1.s2
  beats.i$ses <- ses
    
  return(beats.i)
}


# returns a new list of beats, with
# filtered beats as:
# every S1 must have a second S1 at distance S1-S1 +- tolerance
# before or after
#
# beats.raw    list of all raw beats
# beats.i      indices of S1 and S2 in beats.raw
#
filter.by.s1.s1 <- function(beats.raw, beats.i, sensitivity, plot=FALSE){
 
  if (length(beats.i$s1.i) < 4) {
    return (beats.i)
  }
    
  # find max in density in range > s1.s2 and < 2 sec
  s1.raw.sec <- beats.raw$sec[beats.i$s1.i]
  s2.raw.sec <- beats.raw$sec[beats.i$s2.i]
  s1.s2 <- beats.i$s1.s2

  diffs <- c(diff(s1.raw.sec))
  #           diff(s1.raw.sec, lag = 2), 
  #           diff(s1.raw.sec[-1], lag = 2) )  # add diffs of every second beat
  
  d <- density(diffs, bw="SJ", n=1024)
  if (plot){
    plot(d, main = "Diffs over 2 beats (S1-x-S1)")
    wait.until.enter()
  }
    
  maxi <- find.maxima(d$x, d$y, from=beats.i$s1.s2, to=2.500, win=0.050, overlap=0.5)
  
  # remove all maxima, that are not higher as 1.2 * mean(d)
  # maxi <- maxi[maxi$y / mean(d$y) >= 1.0,]
  
  # order maxima from larg to small
  maxi <- maxi[order(-maxi$y),,drop=FALSE]
  
  # s1.s1 to small
  maxi <- maxi[maxi$t >= CONFIG$s1.s1.min,]
  
  # s1.s1 to big
  maxi <- maxi[maxi$t <= CONFIG$s1.s1.max,]
  
  # return only raw beats, if no maxima in range or to many :
  if (nrow(maxi) == 0) {
    beats.i$s1.s1 <- 0
    return(beats.i)
  }
   
  # if s1.s1 uncelar take larger duration(t) with lower density (y) 
  if(length(maxi$t)>=2){
    maxi.1 <- maxi[1,]
    maxi.2 <- maxi[2,]
    maxi.t <- maxi[order(-maxi$t),,drop=FALSE]
    maxi.1$ind <- which(maxi.t$t==maxi.1$t)
    maxi.2$ind <- which(maxi.t$t==maxi.2$t)
    
    maxi.close <- abs(maxi.1$ind-maxi.2$ind)==1
    
    if(maxi.close){
      
      maxi.t <- merge(maxi.1,maxi.2,all.x = TRUE,all.y =TRUE) # FULL OUTER JOIN
      maxi.t <- maxi.t[order(maxi.t$t),,drop=FALSE]
      
      if(maxi.t$y[2] > maxi.t$y[1] * 0.33){ 
        maxi <- maxi.2
      }else{
        maxi <- maxi.1
      }
      
    }else{
      maxi <- maxi.1
    }

  }

  
  # max value in d, between in window od S1-S1-values
  max.d <- maxi$y
  max.t <- maxi$t
  s1.s1 <- max.t
  beats.i$s1.s1 <- s1.s1
  
  # filter only S1 sounds (S1 must have a partner at s1.s1 +- delta.s1.s1, bifore or after):
  
  # range from half of max.t peak
  max.h <- max.d/2
  limit <- CONFIG$s1.tolerance / sensitivity
  peak.d.x<-d$x[(d$y>=max.h) & (d$x>=(max.t-limit)) &  (d$x<=(max.t+limit))]
  delta.s1.s1 <- (tail(peak.d.x,n=1)-peak.d.x[1])
  delta.s1.s1 <- CONFIG$s1.tolerance / sensitivity # Workaround


  
  # allow only S1 and S2, in a group of 3 beats with s1.s1-Distance
  #
  s1.filter <- unlist(lapply(s1.raw.sec, 
                      function(x){
                        before.s1 <- is.beat.in.range( beats.raw, x - s1.s1 - delta.s1.s1, x - s1.s1 + delta.s1.s1) > 0 
                        before.2.s1 <- is.beat.in.range( beats.raw, x - 2*s1.s1 - delta.s1.s1, x - 2*s1.s1 + delta.s1.s1) > 0 
                        after.s1  <- is.beat.in.range( beats.raw, x + s1.s1 - delta.s1.s1, x + s1.s1 + delta.s1.s1) > 0 
                        after.2.s1  <- is.beat.in.range( beats.raw, x + 2*s1.s1 - delta.s1.s1, x + 2*s1.s1 + delta.s1.s1) > 0 
                        # filter = (before.s1 && after.s1) ||
                        #          (before.s1 && before.2.s1) ||
                        #          (after.s1 && after.2.s1)
                      filter = before.s1 || after.s1
                      return(filter)
                      }))  
  s2.filter <- unlist(lapply(s2.raw.sec, 
                             function(x){
                               before.s2 <- is.beat.in.range( beats.raw, x - s1.s1 - delta.s1.s1, x - s1.s1 + delta.s1.s1) > 0 
                               before.2.s2 <- is.beat.in.range( beats.raw, x - 2*s1.s1 - delta.s1.s1, x - 2*s1.s1 + delta.s1.s1) > 0 
                               after.s2  <- is.beat.in.range( beats.raw, x + s1.s1 - delta.s1.s1, x + s1.s1 + delta.s1.s1) > 0 
                               after.2.s2  <- is.beat.in.range( beats.raw, x + 2*s1.s1 - delta.s1.s1, x + 2*s1.s1 + delta.s1.s1) > 0 
                               # filter = (before.s2 && after.s2) ||
                               #   (before.s2 && before.2.s2) ||
                               #   (after.s2 && after.2.s2)
                               filter = before.s2 || after.s2
                               return(filter)
                             }))  
  
  s1.s2.filter <- s1.filter & s2.filter
  
  beats.i$s1.i <- beats.i$s1.i[s1.s2.filter]  
  beats.i$s2.i <- beats.i$s2.i[s1.s2.filter]  
  
  return( beats.i)
}
