#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

wait.until.enter <- function(){
  cat("Press [enter] to continue\n")
  line <- readline()
}

# uses a spline to stick the kurve to 0.0
#
spline.zero <- function(t, band, all.knots=TRUE, spar=0.65, smooth=FALSE) {
  
  
  # tie to bottom, by:
  # * find minima in 500ms windows
  # * fit spline to minima
  # * substract spline from data

  mins <- find.minima(t, band, from=t[1], to=t[length(t)], win=0.500, overlap=0.0)  
  sp.model <- smooth.spline(mins$t, mins$y, spar=0.25)
  sp.zero <- data.frame(t=t, y=predict(sp.model, t)$y )
  band <- band - sp.zero$y
  
  if (smooth){
    smooth.model <- smooth.spline(t, band, all.knots=TRUE, spar=0.65)
    band <- predict(smooth.model, t)$y
  }
  return(band)
}



# returns a data.frame of minima in the time series band
# default settings finds all beats and extra beats
#
# t        vector of times 
# band     vector of amplitudes
# from     start of region of interest
# to       end of region of interest
# win      window size (minima must be minumum in window)
# overlap  overlap between windows
# maxi     if TRUE, maxima are  returend
#
find.minima <- function(t, band, from, to, win=0.050, overlap=0.5, maxi=FALSE){
  
  len <- length(t)  
  bin <- (t[len]-t[1])/(len-1) 
  step <- ceiling(win / bin)
  win.2 <- ceiling(step/2)
  

  from.i <- round((from - t[1]) / bin) +1
  if (from.i < 1) from.i = 1
  
  to.i <- round((to - t[1]) / bin) +1
  if (to.i > len) to.i <- len
  
  w.from <- from.i
  w.to <- w.from + step
  
  mins.i <- numeric()
  while (w.from < to.i){
    
    wins <- band[w.from:w.to]
    if (maxi) { min.try <- which.max(wins) + w.from -1
    } else { min.try <- which.min(wins) + w.from -1}
    
    check.win.left <-  min.try-win.2
    if (check.win.left < 1) check.win.left <- 1
    check.win.right <-  min.try+win.2
    if (check.win.right > len) check.win.right <- len
    check.win <- seq(check.win.left, check.win.right)
    
    if (maxi) {
      if (band[min.try] >= max(band[check.win])){
        mins.i <- c(mins.i, min.try)
      }
    }else {
      if ( (band[min.try] <= min(band[check.win])) || (min.try <= from.i)  || (min.try >= to.i) ){
        mins.i <- c(mins.i, min.try)
      }
    }   
    w.from <- w.from + floor(step * (1-overlap))
    w.to <- w.from + step
  }
  
  mins.i <- unique(mins.i)
  if (maxi) {
    
    mins.i <- mins.i[(t[mins.i] >= from) & (t[mins.i] <= to)]   # remove maxima out of window
    
  }
  mins <- data.frame(t=t[mins.i], y=band[mins.i])
  return(mins)
}


# returns a data.frame of maxima in the time series band
# default settings finds all beats and extra beats
#
# t        vector of times 
# band     vector of amplitudes
# from     start of region of interest
# to       end of region of interest
# win      window size (minima must be minumum in window)
# overlap  overlap between windows
#
find.maxima <- function(t, band, from, to, win=0.050, overlap=0.5){
  
  return( find.minima(t, band, from, to, win, overlap, maxi=TRUE))
}
    

# returns the index of closest bin in the time series
# 
# t      vector of values, e.g. s1 in sec
# times  vector of time points
#
t2i <- function(t, times) {
  
  return( unlist(lapply(t, function(x){which.min(abs(times-x))})))
}


# returns the value t or smallest or largest value of series
# if t is smaller or larger, repectively.
#
# t       time in sec
# series  timpoints of time series in sec
#
fit2range <- function(t, series){
  
  if (t < min(series)) t <- min(series)
  if (t > max(series)) t <- max(series)
  
  return( t)
}

# insert a new row to a data frame at row index r
# existingDF : as dataframe
# newrow : as nummeric vector
# r : as numeric
#
insertRow <- function(existingDF, newrow, r) {
  existingDF[seq(r+1,nrow(existingDF)+1),] <- existingDF[seq(r,nrow(existingDF)),]
  existingDF[r,] <- newrow
  existingDF
}

