#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# interface.R
# comprises high-level interface functions 
#


pcg.prepare <- function(sample.name){
  
  pcg <- new("PCG", sample.name)
  pcg@spectrum <- pcg.create.spectrum(pcg@wav)
  pcg@bands <- pcg.create.bands(pcg@spectrum)

  #pcg@envelope <- pcg.get.envelope(pcg@wav)
  pcg <- pcg.add.beats(pcg,plot=FALSE)

  
  return(pcg)
}


# Analysis of abnormalities:
# Every beat is checked individually and annotated with symbols
#
# returns a beats-data.frame with annotations
#
#   name         german   score  fun                  comment
#   "S3"         3HT      0                           "3rd heart sound, Kentucky gallop"
#   "S4"         4HT      1      pcg.find.S4()        "4th heart sound, atrial gallop"
#   "SyM"        SyM      1      pcg.find.SyM()       "systolic murmur"
#   "DiM"        DiM      1      pcg.find.DiM()       "diastolic murmur"
#   "S1split"    SP1HT    0                           "splitted 1st heart sound"
#   "S2split"    SP2HT    1      pcg.find.S2split()   "splitted 2nd heart sound"
#
pcg.annotate.abnormalities <- function(pcg) {
 
  beats.scores <- pcg@beats
  
  # check if S1 and S2 beats present:
  if (nrow(beats.scores) > 0) {
    
    beats.scores <- check.s1.s2(pcg)
  }
  
  return( beats.scores)
}



# reads the annotation from "records.abnormal" file
# normal, if not in file
#
pcg.read.annotation <- function(recording){
  
  # read file if not yet read:
  if (length(CONFIG$abnormals) < 2){
    
    file.name <- CONFIG$abnormals.file
    CONFIG$abnormals <- readLines(file.name)
  }
  
  if (recording %in% CONFIG$abnormals) {
    annotation <- "Abnormal"
  }else{
    annotation <- "Normal"
  }
  return(annotation)
}


# Physionet Challenge "next"-function:
# reads a wav file for sample "name" ("name".wav)
# and appends a line to "answers.txt"
#
# name : name of sample (w/o .wav)
#
cinc.next <- function(name){
  
  
  pcg <- pcg.prepare(name)
  pcg@beats <- pcg.annotate.abnormalities(pcg)
  #pcg <- pcg.calc.scores((pcg))
  pcg <- pcg.create.fv(pcg)
  # use only score for prediction:
  # pcg <- pcg.cinc.predict(pcg)
  
  # use LVQ for prediction:
  pcg <- pcg.cinc.lvq(pcg)   # fn() def in cinc.R
  
  prediction <- pcg@cinc$prediction
  if (prediction == "Normal") {
    result <- -1
  
  } else if (prediction == "Abnormal") {
    result <- 1
  
  } else {
    result <- 0
  }
  
  write(paste(name, result, sep=","), file="answers.txt", append=TRUE)
  return(result)
}





# Physionet Challenge "next"-function:
# reads a wav file for sample "name" ("name".wav)
# and appends a line to "answers.txt"
#
# name : name of sample (w/o .wav)
# codes.file : name of file with LVQ codes
#
physionet.next <- function(name, codes.file){
  
  signal <- prepare.one(name, annotation="Unknown", plot=FALSE)
  if (signal$predict == "Too noisy"){
    result <- 0
    
  } else {
    codes <- read.codes(codes.file)
    result <- classify.one(signal, codes)  
  }
  write(paste(name, result, sep=","), file="answers.txt", append=TRUE)
}

