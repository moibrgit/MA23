#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# simon.R
# Comprises functions that implemate Simon's filters for feature
# detection
#

# tests if at time t is an artefact (click or noise), that makes
# the redording unusable at this position.
#
# pcg :    PCG object with spectrum
# t   :    time of interest in sec
#          inspected is the avtivity matrix +- 30 ms left and right
#
pcg.is.artefact <- function(pcg, t){
  
  from = t - 0.030 
  to = t + 0.030
  
  perc <- positive.bins( pcg@bands, 
                         from, 
                         to, 
                         band.names = c("hf2","hf3", "hf4", "hf5", "hf6", "hf7"),
                         active.bands = 4, # fix
                         limit = CONFIG$artefact.limit,
                         abs.limit = FALSE) 
  
  flag.artefact <- perc >= 0.5  # left or rigth drift from higer freqencys
  
  if(flag.artefact){
    
    time <- t2i(c(from,to),pcg@bands$time)
    index <- seq(time[1],time[2])
    pcg <- setartefact(pcg,index=index)
    
  }
  return(list(pcg=pcg, flag.artefact=flag.artefact , perc = perc))
}



# tests if at time t is noise, that makes
# the redording unusable at this position.
#
# pcg :    PCG object with spectrum
# t   :    time of interest in sec
#          inspected is the avtivity matrix +- 100 ms left and right
#
pcg.is.noise <- function(pcg, t){
  
  from = t - 0.100 
  to = t + 0.100
  limit <- pcg.get.band.val(pcg@bands, "beat", t) * 0.4
  
  perc <- positive.bins( pcg@bands, 
                         from, 
                         to, 
                         band.names = c("hf2", "hf3", "hf4", "hf5", "hf6", "hf7"),
                         active.band = 3,
                         limit = limit)
  
  flag.noise <- perc >= 0.9  
  
  if(flag.noise){
    
    time <- t2i(c(from,to),pcg@bands$time)
    index <- seq(time[1],time[2])
    pcg <- setartefact(pcg,index=index)
    
  }
  return(list(pcg=pcg, flag.noise=flag.noise , perc = perc))
}



# search abnormalities in beats
#
# finds abnormalities, if only s1 raw beats have been found
#
check.s1.only <- function(pcg){
  
  beats <- pcg@beats
  return( beats)
}


# finds abnormalities, if s1 and s2 beats have been found
# (normal case)
#
check.s1.s2 <- function(pcg){
  
  beats <- pcg@beats
  bands <- pcg@bands
  n.beats <- nrow(beats)
  
  delta <- 0.025   # peak searching starts delta besides a peak maximum
  
  for (n in CONFIG$ab$name){
    beats[[n]] <- rep(FALSE, n.beats)
  }
  
  for (i in seq_len(n.beats)) {
    
    s1 <- beats[i, "s1"]
    s2 <- beats[i, "s2"]
    
    # CAVE: last and next might be out of range of time series!
    last.s2 <- s1 - pcg@s1.s1 + pcg@s1.s2
    next.s1 <- s1 + pcg@s1.s1
    
    # find S3:
    # diastolic > 110ms after S2
    #
    from <- fit2range(s2 + 0.110, bands$time)
    to <- fit2range( s2 + 0.210, bands$time)
    
    
    ans <- pcg.find.sound(pcg, from = from, to = to, ref.beats = c(s1, s2), limits = c(0.4,0.8,1))    
    beats[i, "S3"] <- ans$flag
    pcg <- ans$pcg
    # cat( paste(" beat", i, "S3", beats[i, "S3"], "\n" ))
    
    
    # find S4:
    # diastolic before S1
    #
    from <- fit2range(s1 - 0.220, bands$time)
    to <- fit2range( s1 - 0.080, bands$time)

    s1.s2.amp <- pcg@bands$beat.zero[t2i(c(s1,s2),pcg@bands$time)]
    ref.beats <- rep(c(s1,s2)[which.max(s1.s2.amp)],2)
    
    ans <- pcg.find.sound(pcg, from = from, to = to, ref.beats = ref.beats, limits = c(0.4,1.0,1))
    beats[i, "S4"] <- ans$flag
    pcg <- ans$pcg
    
    # find SeS:
    # systolic extra sound between S1 and S2
    # FSC / MSC / MVP
    from <- fit2range(s1 + 0.075, bands$time)
    to <- fit2range( s2 - 0.075, bands$time)
    
    # determine max of s1 and s2
    
    s1.s2.amp <- pcg@bands$beat.zero[t2i(c(s1,s2),pcg@bands$time)]
    ref.beats <- rep(c(s1,s2)[which.max(s1.s2.amp)],2)
    
    ans <- pcg.find.sound(pcg, from = from, to = to, ref.beats = ref.beats, limits = c(0.5, 1.3,1))
    beats[i, "SeS"] <- (ans$flag) 
    pcg <- ans$pcg
    
    # find DeS:
    # diastolic extra sound after S2 50-110ms
    #
    from <- fit2range(s2 + 0.050, bands$time)
    to <- fit2range( s2 + 0.110, bands$time)
    
    ans <- pcg.find.sound(pcg, from = from, to = to, ref.beats = c(s1, s2), limits = c(0.4, 1.0,1))
    beats[i, "DeS"] <- ans$flag
    pcg <- ans$pcg
    
    
    
    # find split S2:
    #
    from <- fit2range(s2 - 0.100, bands$time)
    to <- fit2range( s2 + 0.100, bands$time)
    
    beats[i, "S2spl"] <- pcg.find.double(pcg, from = from, to = to, ref.beats = c(s2, s2), limits = c(0.7, 1.3,1))    
    
    
    # find split S1:
    #
    from <- fit2range(s1 - 0.100, bands$time)
    to <- fit2range( s1 + 0.100, bands$time)
    
    beats[i, "S1spl"] <- pcg.find.double(pcg, from = from, to = to, ref.beats = c(s2, s2), limits = c(0.7, 1.3,1))    
    
    
    # find SyM:
    # systolic murmur between S1 and S2
    #
    from <- fit2range(s1 + delta, bands$time)
    to <- fit2range( s2 - delta, bands$time)
    
    ref.i <- t2i(c(s1,s2), bands$time)
    ref <- mean(bands$beat.zero[ref.i])
    perc.hf <- positive.bins( pcg@bands, 
                                 from = from, to = to, 
                                 band.names = c("hf1", "hf2", "hf3","hf4"),
                                 active.band = 3,
                                 limit = ref * 0.1,
                                 art=TRUE)
    
    beats[i, "SyM"] <- (perc.hf > 0.2)
    
    # find SyM 2:
    # if first feature for SyM perc is to less
    if(perc.hf < 0.20){
      
      from.l <- t2i(fit2range(s1 - 0.175 , bands$time),bands$time)
      to.l <- t2i(fit2range(s1 - 0.075, bands$time),bands$time)
      from.r <- t2i(fit2range(s2 + 0.075, bands$time),bands$time)
      to.r <- t2i(fit2range(s2 + 0.175, bands$time),bands$time)
      from.m <- t2i(from +0.05,bands$time)
      to.m <- t2i(to-0.05,bands$time)
      
      #min.l <- pcg@bands$beathigh[from.l:to.l][which.min(pcg@bands$beathigh[from.l:to.l])]
      #min.r <- pcg@bands$beathigh[from.r:to.r][which.min(pcg@bands$beathigh[from.r:to.r])]
      #min.m <- pcg@bands$beathigh[from.m:to.m][which.min(pcg@bands$beathigh[from.m:to.m])]
      
      en.outer <- median(c(pcg@bands$beathigh[from.l:to.l],pcg@bands$beathigh[from.r:to.r]))
      en.inner <- median(pcg@bands$beathigh[from.m:to.m])

      beats[i, "SyM"] <-  en.outer * 5 < en.inner 
    }

    
    
    # find DiM:
    # diastolic murmur after S2 to next s1
    # mitral stenose /trikuspital stenose / aortic insufficiency
    #
    s2.s1 <- pcg@s1.s1 - pcg@s1.s2
    
    from <- s2 + 0.070
    to <- s2  + s2.s1 - 0.020 - CONFIG$s1.tolerance
    
    if(to < from + 0.130){to <- from + 0.130}
    
    from <- fit2range( from , bands$time)
    to <- fit2range( to, bands$time)
    
    ref.i <- t2i(c(s2,s2), bands$time)
    ref <- mean(bands$beat.zero[ref.i])
    
    perc.hf <- positive.bins( pcg@bands, 
                              from = from, to = to, 
                              band.names = c("hf1", "hf2", "hf3","hf4"),
                              active.band = 3,
                              limit = ref * 0.1,
                              art=TRUE)
    
    beats[i, "DiM"] <- (perc.hf > 0.1) 
    

  }
  
  
  
    
  return( beats)
}


# searches for a sound in the pcg and
# returns TRUE if a sound is found or FALSE
#
# from       start time in sec
# to         end time in sec
# ref.beats  value or vector of times of reference beats (S1/S2)
#            intensities of sounds are regarded relative to
#            mean(ampl(ref.beats)
# limits     c(limits.max, limits.min) limits for filtering (0..1)
#            max is only accepted, if max > ref * limit.max
#            min is only accepted, if min < ref * limit.max
#
pcg.find.sound <- function(pcg, from, to, ref.beats, limits=c(0, 1)){
  
  band <- pcg@bands$beat.zero
  t <- pcg@bands$time
  
  ref.i <- t2i(ref.beats, t)
  ref <- mean(band[ref.i])
  
  maxis <- find.minima(t, band, from, to, maxi=TRUE)
  minis <- find.minima(t, band, from, to, maxi=FALSE)
  
  # filter:
  maxis <- maxis[(maxis$y > limits[1] * ref) & (maxis$y < limits[2] * ref),]
  minis <- minis[minis$y < limits[3] * ref,]
  
  
  
  # a sound is only a sound, if a minimum is left and right:
  sound.found <- FALSE
  for (i in seq_along(maxis$t)) {
    
    i.t <- maxis[i,"t"]
    if ( (length(minis$t[minis$t < i.t]) > 0) && (length(minis$t[minis$t > i.t]) > 0) ){
      
      ans <- pcg.is.artefact(pcg, i.t)
      pcg <- ans$pcg
      flag.artefact <- ans$flag.artefact
      
      if (!flag.artefact) {
        sound.found <- TRUE
      }
    }
  }
  
    
  return (list(pcg=pcg, flag=sound.found))
}



# searches for a double sound in the pcg and
# returns TRUE if a sound is found or FALSE
#
# from       start time in sec
# to         end time in sec
# ref.beats  value or vector of times of reference beats (S1/S2)
#            intensities of sounds are regarded relative to
#            mean(ampl(ref.beats)
# limits     c(limits.max, limits.min) limits for filtering (0..1)
#            max is only accepted, if max > ref * limit.max
#            min is only accepted, if min < ref * limit.max
#
pcg.find.double <- function(pcg, from, to, ref.beats, limits=c(0, 1)){
  
  band <- pcg@bands$beat.zero
  t <- pcg@bands$time
  
  ref.i <- t2i(ref.beats, t)
  ref <- mean(band[ref.i])
  
  maxis <- find.minima(t, band, from, to, win=0.030, maxi=TRUE)
  minis <- find.minima(t, band, from, to, win=0.030, maxi=FALSE)
  
  # filter:
  maxis <- maxis[maxis$y > limits[1] * ref,]
  minis <- minis[minis$y < limits[2] * ref,]
  
  # a sound is only split, if a minimum is between left and right peak:
  double.found <- FALSE
  for (i in seq_along(minis$t)) {
    
    i.t <- minis[i,"t"]
    if ( (length(maxis$t[maxis$t < i.t]) > 0) && (length(maxis$t[maxis$t > i.t]) > 0) ) {
      double.found <- TRUE
    }
  }
  
  
  return (double.found)
}




# test for activity in bands and 
# returns the percent of time-bins, in which the condition is fullfilled
#
# bands        bands data.frame
# from         start time in sec
# to           end time in sec
# band.names   vector of band names to be tested
# active.bands number of bands, that must be active simultaniously
# limit        minimum activity in band to be regarded as active
# art          if FALSE detected artefacts are ignored in sums
#
positive.bins <- function(bands, from, to, band.names, active.bands, limit, art=FALSE, abs.limit = TRUE) {
  
  binary.matrix <- get.binary.matrix(bands, from, to, band.names, limit, abs.limit=abs.limit)
  sums <- rowSums(binary.matrix)
  sums <- ifelse(sums >= active.bands, 1, 0)
  
  
  if(art){
    win <-t2i(c(from,to),bands$time)
    artefact <- bands$artefact[(win[1]+1):(win[2]-1)]
    if(length(sums)==length(artefact))
    {
      sums <- sums[artefact==0]
    }
  }
  
  percent <- mean(sums)
  return(percent)
}

# returns a matrix of 
# rows :   time bins in time range
# cols :   bands
#
# Matrix element is 1, if there is activity above limit
#
# bands        bands data.frame
# from         start time in sec
# to           end time in sec
# band.names  vector of band names to be tested
#
get.binary.matrix <- function(bands, from, to, band.names, limit , abs.limit = TRUE) {
  
  region <- get.activity.matrix(bands, from, to, band.names)  

  if(abs.limit){
    active <- ifelse(region > limit, 1, 0)
    
  }else{ # rel.Limits
    
    bands.mean <- colMeans(bands[,band.names])
    bands.mean <-  ifelse(bands.mean <0.01, 0.1,bands.mean) # if mean --> 0 
    
    active <- ifelse(region/bands.mean > limit, 1, 0)
  }
  return(active)
}
# returns a matrix of 
# rows :   time bins in time range
# cols :   bands
#
# Matrix element is activity in bin
#
# bands        bands data.frame
# from         start time in sec
# to           end time in sec
# band.names  vector of band names to be tested
#
get.activity.matrix <- function(bands, from, to, band.names) {

  # make indices of time-bins in bands  
  t <- bands$time
  t.i <- which(t>=from & t<=to)

  region <- bands[t.i, band.names]  
  return( region)
}





# returns the ampl at time t in band band.name
#
# t          time in sec
# band.name  name of band
#
pcg.get.band.val <- function( bands, band.name, t){
 
  t.i <- which.min(( abs( bands$time - t))) 
  return(bands[t.i, band.name])
}

