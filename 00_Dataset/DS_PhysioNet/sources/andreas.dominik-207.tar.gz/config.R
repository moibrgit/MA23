#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# config.R
# Global configuration settings
#

CONFIG <- list(description="Configuration of Physionet 2016 entry, ADo")

CONFIG$sample.dir <- "/home/andreas/Documents/Projekte/2016-CinC/Data-Train-allF/all/"
CONFIG$abnormals.file <- "abnormal.all"
CONFIG$abnormals <- "not read"

# freq-bands for spectrum
CONFIG$bands <- data.frame(low= c(20,  50), 
                           beat=c(20, 250),
                           beathigh=c(50,150),
                           hf1=c(250, 350),
                           hf2=c(350, 450),
                           hf3=c(450, 550),
                           hf4=c(550, 650),
                           hf5=c(650, 750),
                           hf6=c(750, 850),
                           hf7=c(850, 950), 
                           stringsAsFactors = FALSE)

# Params for beat detection:
#
CONFIG$min.beats <- 3       # minimum beats necessary; otherwise => noisy samle
CONFIG$whish.rate <- 0.6    # wanted average number of recognised beats per sec (i.e. 0.5 == 5 beats in a 10sec sample)
CONFIG$s1.tolerance <- 0.075 # sec: S1 is detectd if another S1 is found at S1-S1 +- tolerance 
                             # before od after the peak
CONFIG$s1.s1.min <- 0.4      # s1.s1 duration has to be limitated [150Hz]
CONFIG$s1.s1.max <- 1.5      # [45Hz]

CONFIG$s2.tolerance <- 0.055 # sec: S2 is detectd if it is S1-S2 +- tolerance after a S1
CONFIG$artefact.limit <- 1.2 # regions in bands for artefact detection have to be 1.2 times greater than mean activation from bands 

# data.frame with all abnormalities
CONFIG$ab <- data.frame(
  name   = c("S3",  "S4",  "SeS", "DeS", "SyM", "DiM", "S1spl", "S2spl"),
  german = c("3HT", "4HT", "SeT", "DeT", "SyM", "DiM", "SP1HT", "SP2HT"),
  score  = c( 0.5,   0.8,   0.2,     1,     1,     0.6,     0,     0),
  norm   = c( T,     F,     F,     T,     F,       F,       T,       T),
  comment= c("3rd heart sound, Kentucky gallop",
             "4th heart sound, atrial gallop",
             "systolic extra sound",
             "diastolic extra sound",
             "systolic murmur",
             "diastolic murmur",
             "splitted 1st heart sound",
             "splitted 2nd heart sound")
  )

# Parameters for Classification
#
CONFIG$num.codebook <- 100
CONFIG$num.iter.lvq1 <- CONFIG$num.codebook *50
CONFIG$num.iter.lvq2 <- CONFIG$num.codebook *50
CONFIG$alpha <- 0.1

CONFIG$vote.min <- 1
CONFIG$vote.r <- 2.5
CONFIG$vote.k <- 1

CONFIG$codes.file <- "lvqmodel.rds"  # filename for trained LVQ model


