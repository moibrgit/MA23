#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#


#
# methods for classifier
#
#
# ADo/SHo

#
# lvq from class library
#
#
# trains an lvq with lvq1 and lvq2. Defaults to values from CONFIG.
#
# data : dataset as data.frame with cols: 
#        name class bin1 bin2 ...
# num.codes : number of codes
# lvq1 : num of iterations for lvq1
# lvq2 : num of iterations for lvq2
#
train.lvq <- function(data, 
                      num.codes=CONFIG$num.codebook,
                      lvq1.iter=CONFIG$num.iter.lvq1,
                      lvq2.iter=CONFIG$num.iter.lvq2) {
  
  
  train <- as.matrix(data[,(names(data) != "name") & (names(data) != "class")])
  
  # normalise all columns:
  train.n <- scale(train, center=TRUE, scale=TRUE)
  scale.center <- attr(train.n, "scaled:center")
  scale.scale <- attr(train.n, "scaled:scale")
  
  train.n <- as.matrix(train.n)
  
  classes <- as.factor(data$class)
  alpha <- CONFIG$alpha
  
  # LVQ INI
  codes <- lvqinit(train.n, classes, size=num.codes, prior = c(0.5,0.5))
  # LVQ TRAIN
  codes <- lvq1( train.n, cl=classes, codebk=codes, niter=lvq1.iter, alpha=alpha)
  codes <- lvq2( train.n, cl=classes, codebk=codes, niter=lvq2.iter, alpha=alpha)
  
  cinc.model <- list(model=codes, scale.center=scale.center, scale.scale=scale.scale)
  class(cinc.model) <- c("CinCmodel", class(cinc.model))
  return( cinc.model)
}


# Performs 1/3rd xval. Parameters from CONFIG
#
# data : datasets
# 
xval.33 <- function( data){
  
  # make 3 sets for Xval
  test.1 <- extract.X.test(data , 3, 1)
  train.1 <- extract.X.train(data, 3, 1)
  
  test.2 <- extract.X.test(data, 3, 2)
  train.2 <- extract.X.train(data, 3, 2)
  
  test.3 <- extract.X.test(data, 3, 3)
  train.3 <- extract.X.train(data, 3, 3)
  
  # run 3 xvalidations
  kernel <- CONFIG$knn.kernel
  
      print(paste("1st 3rd of Xval training with ", nrow(train.1), "training samples.")) 
  codes.1 <- train.lvq(train.1)
      print(paste("1st 3rd of Xval validation with ", nrow(test.1), "validation samples."))
  result.1 <- vote.lvq(test.1, codes.1, kernel)
  
      print(paste("2nd 3rd of Xval with ", nrow(train.2), "training samples.")) 
  codes.2 <- train.lvq(train.2)
      print(paste("2nd 3rd of Xval validation with ", nrow(test.2), "validation samples."))
  result.2 <- vote.lvq(test.2, codes.2, kernel)
  
      print(paste("3rd 3rd of Xval with ", nrow(train.3), "training samples.")) 
  codes.3 <- train.lvq(train.3)
      print(paste("3rd 3rd of Xval validation with ", nrow(test.3), "validation samples."))
  result.3 <- vote.lvq(test.3, codes.3, kernel)

  result <- rbind(result.1, result.2, result.3)
  result <- result[order(result$name),]
  
  return(result)
}

# extracts a test dataset for X-validation from normal and abnormal dataset
#
# data : dataset with normal and abnormal training samples
# num.X : how many X-validation runs?
# num.run : current X-val run
#
extract.X.test <- function(data, num.X, num.run) {

  normal <- data[data$class=="Normal",]
  abnormal <- data[data$class=="Abnormal",]
  
  num.run <- num.run -1
  data <- rbind( normal[seq_along(normal$name) %% num.X == num.run, ],
                 abnormal[seq_along(abnormal$name) %% num.X == num.run, ])
  
  data <- data[order(data$name),]
  
  return( data)
}

# extracts a training dataset for X-validation from normal and abnormal dataset
#
# normal : dataset with normal train samples
# abnormal : dataset with abnormal train samples
# num.X : how many X-validation runs?
# num.run : current X-val run
#
extract.X.train <- function(data, num.X, num.run) {
  
  normal <- data[data$class=="Normal",]
  abnormal <- data[data$class=="Abnormal",]
  
  num.run <- num.run -1
  normal <- normal[seq_along(normal$name) %% num.X != num.run, ]
  abnormal <- abnormal[seq_along(abnormal$name) %% num.X != num.run, ]
  
  # balance = make both sets same length:
  n.normal <- length((normal$name))
  n.abnormal <- length((abnormal$name))
  if (n.normal < n.abnormal) {
    normal <- normal[rep(seq_along(normal$name), len=n.abnormal), ]
  } else {
    abnormal <- abnormal[rep(seq_along(abnormal$name), len=n.normal), ]
  }
  
  data <- rbind( normal, abnormal)
  data <- data[sample(seq_along(data$name)),]
  
  return( data)
}

# calculates votes for Normal and Abnormal for all records in 
# dataset data.
#
# data : dataset
# codes : codebook vectors in a list of type CinCmodel
# min.vote : minimal vote: if all votes < min.vote, class id "Too noisy"
# min.diff : minimal difference: if diff. between votes < min.diff, class is "Too noisy"
#
vote.lvq <- function(data, codes, kernel, ...){

  votes <- data.frame(name=character(0), class=character(0), 
                      vote.normal=numeric(0), vote.abnormal=numeric(0), k.neighbours=numeric(0),
                      prediction=character(0),
                      stringsAsFactors=FALSE)
  
  # loop all samples in data:
  for (i in seq_along(data$name)) {
    
    one.votes <- vote.one(data[i,], codes)
    votes <- rbind(votes, one.votes)
  }
  
  return( votes)
}

# votes one test sample and calls class.knn 
#
# data : data.frame with one recird to vote
# model : codebook from class.lvq
# k:
# r:
#
vote.one <- function(data, model, k = CONFIG$vote.k  ,r = CONFIG$vote.r ){
  
  print(paste("Voting sample", data$name[1]))
  codebook <- model$model
  
  #scale/normalise with info from model:
  one.name <- data[1,"name"]
  one.class <- data[1,"class"]
  data.nums <- data[1, !names(data) %in% c("name", "class")]
  data.scaled <- scale(data.nums, center=model$scale.center, scale=model$scale.scale)
  data <- cbind(data.frame(name=one.name, class=one.class), data.scaled)
  
  vote <- vote.one.knn(data, codebook, k=k, r=r)

  return( vote)
}


# calculates votes for Normal and Abnormal for one record in 
# dataset data with k-nn.
#
# data : dataset with one record
# codes : codebook vectors
# min.vote : minimal vote: if all votes < min.vote, class id "Too noisy"
# min.diff : minimal difference: if diff. between votes < min.diff, class is "Too noisy"
# k : number of neighbours to be considered
# r : only neighbours with dist < r are considered
#
vote.one.knn <- function(data, codebook, min.vote=CONFIG$vote.min, min.diff=1, 
                         k=1, r=CONFIG$vote.r){
  
  codes <- codebook$x 
  cl <- codebook$cl
  d <- as.vector(as.matrix((data[1, !names(data) %in% c("name", "class")])))
  
  
  # calc. distances:
  # and remove if dist > r
  # and order:
  distances <- apply(codes, 1, function(x){sqrt(sum((x-d)^2))}) # ||L||
  selection <- distances < r
  distances <- distances[selection]
  cl <- cl[selection]
  
  if(length(cl)!=0){
    
    cl <- cl[order(distances)]
    
    if(length(cl)>=k){
      cl <- cl[1:k]
    }

    # sum up votes:
    normal <- length(cl[cl=="Normal"])
    abnormal <- length(cl[cl=="Abnormal"])
    
    k.neighbours <- length(cl)
    
    if ((normal < min.vote) && (abnormal < min.vote)) {
      predict <- "Uncertain"
      
    } else {
      if (abs(normal - abnormal) < min.diff) {
        predict <- "Uncertain"
        
      } else {
        if (normal > abnormal) {
          predict <- "Normal"
        } else {
          predict <- "Abnormal"
        }
      }
    }
  } else {
  # if r is to small -> no k 
    predict <- "Uncertain"
    abnormal <- 0
    normal <- 0
    k.neighbours <- 0
  }

  vote <- data.frame(name=data$name, class=data$class, 
                     vote.normal=normal, vote.abnormal=abnormal, k.neighbours=k.neighbours,
                     prediction=predict,
                     stringsAsFactors=FALSE)
  return( vote)  
}


# saves LVQ codes to a file in R binary format
# to be read again with load()
#
# codes : codes object
#
save.codes <- function(codes, file=CONFIG$codes.file){
  
  saveRDS(codes, file=file)
}

# Read LVQ codes from a file in R binary format
# written by save.codes
#
# file : name of file
#
read.codes <- function(file=CONFIG$codes.file){
  
  codes <- readRDS(file=file)
  return( codes)
}

