#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# cinc.R
# Comprises functions to calculate scores for normal/abnormal assessment.
#

#
# calculates scores from the abnormalitiy-matrix in @beats
# and returns an updated pcg with
# scores for abnormalities
# and tital score
#
pcg.calc.scores <- function( pcg) {
  
  if (nrow(pcg@beats) > 0){
   
    score.df <- pcg@beats[!(names(pcg@beats) %in% c("s1", "s2"))]
    score.matrix <- ifelse(as.matrix(score.df), 1.0, 0.0)
    sums <- colSums(score.matrix)
    
    # sum up scores for individual abnormalities:
    scores <- sums * CONFIG$ab$score
    
    # normalise if defined in CONFIG:
    for (i in seq_along(CONFIG$ab$score)){
      
      if (CONFIG$ab$norm[i]){
        scores[i] <- scores[i] / nrow(pcg@beats)
      }
    }
    score <- sum(scores)
    
    
    cinc <- list(scores = scores, score = score)
  } else {
    
    cinc <- list(scores = rep(0.0, length(CONFIG$ab$score)), score = 0.0, score.beat = 0.0)
  }
   pcg@cinc <- cinc
  
  return( pcg)
}


# create feature vector from record
# 
pcg.create.fv<- function(pcg){
  
     
  beats.f <- lapply(pcg@beats,function(x){sum(x)})
  beats.f <- beats.f[-c(1,2)] #remove s1 and s2
  
  if(length(beats.f)!=0){
    
    for (i in seq_along(CONFIG$ab$name)){
      
      beats.f[i] <- beats.f[[i]] * CONFIG$ab$score[i]
    
      # normalise to #beats if defined in CONFIG:
      if (CONFIG$ab$norm[i]){
        beats.f[i] <- beats.f[[i]] / nrow(pcg@beats)
      }
      
    }
    
    cinc <- list(beats.f = beats.f)
    pcg@cinc <- cinc
    pcg@cinc$prediction <- ""
    return(pcg)
    
  } else {
    # no beats / too noisey /
    pcg@cinc$prediction <- "Uncertain"
    return(pcg)
  }

}

# predicts the sample as Normal, Uncertain or Abnormal
#
pcg.cinc.predict <- function(pcg){
  
  if (nrow(pcg@beats) == 0) {
    
    prediction <- "Uncertain"
    
  } else {
    prediction <- "Normal"
    
    if( pcg@cinc$score > 2) prediction <- "Abnormal"
  }
  
  pcg@cinc$prediction <- prediction
  return(pcg)
}


## NEW
# classifies one signal. Codes are read from the rds-file
# codes.file.
# kNN-classifier is applied according to settings in CONFIG
#
# signal : object of type signal
# codes.file : name of file with LVQ codes
#
pcg.cinc.lvq <- function(pcg){
  
  if ( !("prediction" %in% names(pcg@cinc))) { pcg@cinc$prediction <- "Unknown" }
    
  if (pcg@cinc$prediction == "Uncertain") { prediction <- "Uncertain"
    
  } else if (nrow(pcg@beats) < 6) {         prediction <- "Uncertain"
    
  } else {
    
    codes <- read.codes(CONFIG$codes.file)
    data.set <- as.data.frame(pcg@cinc$beats.f)
    data.set <- data.set[, !names(data.set) %in% c("S1spl", "S2spl")]  # remove unused Splits
    data.set$name <- pcg@name
    data.set$class <- pcg@cinc$prediction
    
    vote <- vote.one(data.set, codes)
  
    if (nrow(vote) == 1){
      prediction <- vote[1,"prediction"]
    } else {
      prediction <- "Uncertain"
    }
  }
  
  pcg@cinc$prediction <- prediction
  
  return( pcg)
}




# calculates the scores for a classification.
# returns a list of: 
#     normal.correct, normal.wrong,
#     abnormal.correct, abnormal.wrong,
#     uncertain,
#     selectivity, sensitivity, score (Physionet 2016).
#
# result : data.frame of type result with cols:
#          name, class, score, predict
#
calc.CinC.score <- function(result){
  
  #    reference   output
  # Nn normal      normal
  # An abnormal    normal
  # Na normal      abnormal
  # Aa abnormal    abnormal
  # Nq normal      unknown
  # Aq abnormal    unknown
  Nn <- nrow( result[(result$class == "Normal") & (result$prediction == "Normal"), ])
  Na <- nrow( result[(result$class == "Normal") & (result$prediction == "Abnormal"), ])
  Nq <- nrow( result[(result$class == "Normal") & (result$prediction == "Uncertain"), ])
  
  Aa <- nrow( result[(result$class == "Abnormal") & (result$prediction == "Abnormal"), ])
  An <- nrow( result[(result$class == "Abnormal") & (result$prediction == "Normal"), ])
  Aq <- nrow( result[(result$class == "Abnormal") & (result$prediction == "Uncertain"), ])
  
  w <- 0.5  
  Se <- (Aa + w * Aq) / (Aa + Aq + An)
  Sp <- (Nn + w * Nq) / (Na + Nq + Nn)
  
  score <- (Se + Sp) / 2 
  
  percent.correct <- (Nn + Aa) / nrow(result) * 100
  
  CinC.score <- list( Nn=Nn, Na=Na, Nq=Nq,
                  Aa=Aa, An=An, Aq=Aq,
                  Se=Se, Sp=Sp, percent.correct=percent.correct, 
                  score=score)
  
  return(CinC.score)
}

# nicer print for result:
#
print.CinC.score <- function(x){
  
  print( sprintf("          %6s %6s %6s",  "corr.", "wrong", "unk."))
  print( sprintf("Normals   %6d %6d %6d",  x$Nn, x$Na, x$Nq))
  print( sprintf("Abnormals %6d %6d %6d",  x$Aa, x$An, x$Aq))
  print( sprintf("Selectivity %6.2f, Specifity %6.2f, %% correct %6.2f",  x$Se, x$Sp, x$percent.correct))
  print( sprintf("CinC Score  %6.2f",  x$score))
}
