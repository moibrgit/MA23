#      This file is part of the Physionet 2016 Challenge entry of the team
#      S. Hofmann/A. Dominik.
#
#      Copyright (c) 2016 THM University of Applied Sciences, Giessen, Germany
#                         Andreas Dominik
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# pcg.R
# Comprises functions to create and work with PCGs
#

require(tuneR)
require(seewave)

# Define S4 class for PCG:
#
setClass( Class="PCG", 
          representation = representation(
                              name="character",             # sample name
                              comment="character",      
                              annotation="character",       # Normal or Abnormal provided from CinC-file
                              wav="Wave",                   # TuneR Wave Object
                              duration="numeric",           # total duration of the PCG in sec
                              spectrum="list",              # elements: 
                                                            #           ampl [freqs,bins]
                                                            #           pow [freqs,bins]
                                                            #           time [bins]
                                                            #           freq [freqs]
                              envelope="data.frame",        # nomalised Hilbert-Envelope with:
                                                            #           time [sec]
                                                            #           hilbert
                              bands="data.frame",           # elements: 
                                                            #           time
                                                            #           index
                                                            #           low
                                                            #           beats
                                                            #           hf1, ... , hf7
                                                            #           artefact
                              s1.s1="numeric",              # s1-s1 dist in sec
                              s1.s2="numeric",              # s1-s2 dist in sec
                              raw.beats="numeric",          # all detected raw beats w/o S1/S2-filtering
                              beats="data.frame",           # elements: 
                                                            #           s1 (sec)
                                                            #           s2 (sec)
                                                            #           feature1, ..., n (T/F)
                              cinc="list"                   # cinc prediction; elements:
                                                            #           scores      for individual abnormalities
                                                            #           score       sum of scores
                                                            #           score.beat  normalised score/beat
                                                            #           prediction  "Normal", "Abnormal" or "Uncertain"
                             )
                                                        
          )

# set default methods:
#
setMethod( "print", "PCG", 
           function(x, ...){
             cat("Object of type PCG\n")
             cat(paste("  Sample name:   ", x@name, "\n", sep=""))
           }
         )

setMethod( "show", "PCG",
           function(object){
             cat("Object of type PCG\n")
             cat(paste("  Sample name:   ", object@name, "\n", sep=""))
             cat(paste("  # Beats:       ", nrow(object@beats), "\n", sep=""))
             cat(paste("  S1-S1:         ", object@s1.s1, "\n", sep=""))
             cat(paste("  S1-S2:         ", object@s1.s2, "\n", sep=""))
           }
         )

# setter method for artefacts in bands
#
setGeneric(name="setartefact",
           def=function(pcg,index)
           {
             standardGeneric("setartefact")
           }
)
setMethod("setartefact","PCG",
          
            function(pcg,index){
              pcg@bands$artefact[index] <- rep(1,length(index))
              validObject(pcg)
              return(pcg)
            }
          )


# constructor
#
setMethod("initialize", "PCG",
          function(.Object, sample.name="no name"){
            
            if (sample.name == "no name") {
              .Object@comment <- paste("Empty PCG object")
            } else {
            
              wav <- read.recording(sample.name)
              .Object@wav <- wav
              .Object@name <- sample.name
              .Object@comment <- paste("Phonocardiogram of sample", sample.name)
              .Object@duration <- duration(wav)
            }
            return(.Object)
          }
)

            
            
 
# S3 plot method for PCG
#
# pcg     list of type PCG
# what    vector of elements to plot c("wave", "spectrum", "envelope", "artefacts","bands","zero")
#
setMethod( "plot", "PCG",
  function(x, what=c("wave", "spectrum", "bands", "beats"),...){

    
    # add beats to a plot:
    #
    add.beats <- function(y.beats){
      
      if (("beats" %in% what) && (nrow(x@beats) > 0)) {
        
        beats <- x@beats
        y.s1 <- y.beats
        y.s2 <- y.beats * 0.95
        points(beats$s1, rep(y.s1, length(beats$s1)), pch=18, col="red")
        
        if (max(beats$s2) > 0) # s2 only if vals there
          points(beats$s2, rep(y.s2, length(beats$s2)), pch=18, col="blue")
        
      }
    }
    
    
    name <- x@name
    # plot wave:
    if ("wave" %in% what) {
      
      # plot complete Envelope and WAV:
      wav <- x@wav
      t <- seq(from=0, by=1/wav@samp.rate, length.out=length(wav@left))
      amp <- wav@left
      plot(t, amp, type="l", col="blue",
           main = paste(name, "- left channel", sep=" "),
           ylab="amp", xlab="t [sec]", 
           ...)
      
      add.beats(max(amp) * 0.9);
    }

    # plot spectrum:
    if ("spectrum" %in% what){
      spectrum <- x@spectrum
  
      image(spectrum$time, spectrum$freq, t(spectrum$amp), col=topo.colors(24), 
          zlim=c(0.01, 30+15), 
          xaxs="i", 
          xlab="t [sec]", ylab="f [Hz]", main=paste(name, "-", "Spectrum"),
          ...)
  
     add.beats(900);
    }
    bands <- x@bands
    # plot bands:
    if ("bands" %in% what){
      
      if("zero" %in% what){
        y1=bands$beat.zero
        y2=bands$low.zero
      }else{
        y1=bands$beat
        y2=bands$low
      }
      
      # bands:
      plot(x=bands$time, y=y1, type="l", ylim=c(0,30+15), xaxs="i", 
      xlab="t [sec]", ylab="amp", main=paste(name, "-", "Bands"),
         ...)
  
      lines(x=bands$time, y=y2, col="red")
      #lines(x=bands$time, y=spline.zero(bands$time, bands$beat), col="blue")
      lines(x=bands$time, y=bands$beathigh, col="grey")
      lines(x=bands$time, y=bands$hf1, col="purple")
      lines(x=bands$time, y=bands$hf2, col="green")
      lines(x=bands$time, y=bands$hf3, col="royalblue")
      lines(x=bands$time, y=bands$hf4, col="magenta1") 
      lines(x=bands$time, y=bands$hf5, col="darkorange")
      lines(x=bands$time, y=bands$hf6, col="saddlebrown")
      lines(x=bands$time, y=bands$hf7, col="turquoise1")
      lines(x=bands$time, y=bands$artefact*45, col="forestgreen")
  
      
      legend(
      "topleft",
      c("beat","low","high","hf1","hf2","hf3","hf4","hf5","hf6","hf7","artefact"),
      lty= c(1,1,1,1,1,1,1,1,1,1),
      col = c("black","red","grey","purple","green","royalblue","magenta1","darkorange","saddlebrown","turquoise1","forestgreen"),
      text.col = "green4",
      bty="n",
      y.intersp = 0.3)
      
      add.beats(max(bands$low) * 0.9)
    }
    
    # plot envelope:
    if ("envelope" %in% what){
      env <- x@envelope
      
      plot(x=env$time, y=env$hilbert, type="l", xaxs="i", 
           xlab="t [sec]", ylab="amp", main=paste(name, "-", "normalised Envelope"),
           ...)
      
      
      
      add.beats(1.0);
    }
    
  }
)